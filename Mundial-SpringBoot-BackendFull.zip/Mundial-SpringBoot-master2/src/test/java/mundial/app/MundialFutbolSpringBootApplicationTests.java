package mundial.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MundialFutbolSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
